import tkinter as tk
from PIL import Image, ImageTk
import qrcode

qr = qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
)
# create the main window
root = tk.Tk()

# set the window title
root.title("QR Code Generator App")

# create a label for the input box
label_input = tk.Label(root, text="Enter your input:", )
label_input.pack()

# create the input box
input_box = tk.Entry(root, width=50)
input_box.pack()

# create a frame for the buttons
button_frame = tk.Frame(root)
button_frame.pack(pady=10, padx=5)

#canvas = tk.Canvas(root, width=300, height=300)
#canvas.pack()


def generateCode():
    links = input_box.get()
    print(links)
    qr.add_data(links)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save("images/qr_code.png")
    # img=Image.open("images1/qr_code.png")
    #images = tk.PhotoImage(file=r'images\qr_code.png')
    #print(images)
    # cv.pack(side='top', fill='both', expand='yes')
    #canvas.create_image(10, 10, image=images, anchor='nw')
    image1 = Image.open("images/qr_code.png")
    test = ImageTk.PhotoImage(image1)
    label1 = tk.Label(image=test)
    label1.image = test
    label1.pack()



def clearImage():
    canvas.delete("all")


# create the first button
button1 = tk.Button(button_frame, text="Generate", bg="green", width=20, command=generateCode)
button1.pack(side=tk.LEFT)

# create the second button
button2 = tk.Button(button_frame, text="Clear", bg="red", width=20, command=clearImage)
button2.pack(side=tk.LEFT)

# create a canvas for displaying images
# canvas = tk.Canvas(root, width=300, height=300)
# canvas.pack()

# create an image to display on the canvas
# image = tk.PhotoImage(file="images/qr_code.png")

# display the image on the canvas
# canvas.create_image(0, 0, anchor=tk.NW, image=image)
# canvas.create_image(10, 10, image=image, anchor='nw')

# start the main event loop
root.mainloop()
